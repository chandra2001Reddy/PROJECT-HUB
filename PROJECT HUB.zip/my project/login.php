<?php
mysqli_connect('localhost','root','',login);
    $user namespace = $_POST['user name'];
    $user password = $_POST['password'];
    $conn=new mysqli('localhost','root','','login');
    if($conn->connect_error){
        die('connection failed :'.$conn->connect_error);
    }
    else{
        $stmt=$conn->prepare("select * from registeration where email =?");
        $stmt->bind_param("s",$user name);
        $stmt->execute();
        $stmt-result=$stmt->get_result();
        if($stmt_result->num_rows >0){
            $data =$stmt_result->fetch_assoc();
            if($data['password']===$password){
                echo "<h2>login.successfully</h2>";
            }
        }
        else{
            echo "<h2"invali email or password</h2>";  
        }
       
    }
?>

