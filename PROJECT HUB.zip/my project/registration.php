<?php
    $user FIRSR NAME = $_POST['FIRST NAME'];
    $user LAST NAME = $_POST['LAST NAME'];
    $user E-MAIL = $_POST['E-MAIL'];
    $user PHONE NUMBER = $_POST['PHONE NUMBER'];
    $user password = $_POST['password'];

    
    $conn=new mysqli('localhost','root','','registration');
    if($conn->connect_error){
        die('connection failed :'.$conn->connect_error);
    }
    else{
        $stmt=$conn->prepare("insert into registration(FIRST NMAE,LAST NAME,E-MAIL,PHONE NUMBER,PASSSWORD")values(?,?,?,?,?);
        $stmt->bind_param("sssss",$FIRST NAME,$LAST NAME,$E-MAIL,$PHONE NUMBER,$PASSWORD);
        $stmt->execute();
        echo->close();
        $conn->close();
    }
?>